export class Pelicula {
     
    constructor(id, nombre, genero, director, pais, precio, copias, imagen, ventas) {
        this.id = id;
        this.nombre = nombre;
        this.genero = genero;
        this.director = director;
        this.pais = pais;
        this.precio = precio;
        this.copias = copias;
        this.imagen = imagen;
        this.ventas = ventas;
    }

}