export class Alquiler {
     
    constructor(id, fecha, nombre, telefono, pelicula) {
        this.id = id;
        this.fecha = fecha;
        this.nombre = nombre;
        this.telefono = telefono;
        this.pelicula = pelicula;
    }

}